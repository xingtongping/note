package sfs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @作者：Administrator
 * @创建时间：2020/8/27 9:51
 * @类描述：
 */
@Component
public class ProductConsumerController {

    @Autowired
    ProductService productService;


    /**
     * 查询
     * @return
     */
    @GetMapping("/test")
    public String test(){
        return productService.index("xtp");
    }
}
