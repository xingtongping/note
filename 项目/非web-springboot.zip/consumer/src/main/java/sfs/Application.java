package sfs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import sfs.common.dbcomponent.SFSDatabase;

import java.util.List;
import java.util.Map;

/**
 * @作者：Administrator
 * @创建时间：2020/8/27 11:03
 * @类描述：在Spring Boot中，要创建一个非Web应用程序，实现CommandLineRunner并覆盖run()方法，pom依赖：spring-boot-starter库
 * 说明：1、执行完最后报Shutdown in progress错误，不影响执行
 * 2、配置文件设置robbin超时时长，否则报错Read timed out executing GET
 *
 * maven引入SFSDatabase两个包，我这里手动引入项目，未在pom文件添加
 */
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
@EnableFeignClients
public class Application implements CommandLineRunner {

    @Autowired
    SFSDatabase sfsDatabase;
    @Autowired
    ProductConsumerController productConsumerController;

    public void run(String... args) throws Exception {
        System.out.println(sfsDatabase);
        List<Map<String,Object>> resultList=sfsDatabase.SQL.queryListMap("select * from test");
        System.out.println(String.format("%d",resultList.size()));
        System.out.println(productConsumerController.test());
        System.out.println("==========================");
    }

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

}
