package com.example.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @作者：Administrator
 * @创建时间：2020/8/27 9:51
 * @类描述：
 */
@RestController
public class ProductConsumerController {
    @Autowired
    ProductService productService;

    /**
     * 查询
     * @return
     */
    @GetMapping("/test")
    public String test(){
        return productService.index("xtp");
        /*return new Result(200, "查询成功",
                restTemplate.getForObject(url+"product/provider/get/info", Result.class));*/
    }
}
