package com.example.provider.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @作者：Administrator
 * @创建时间：2020/8/27 9:39
 * @类描述：
 */
@RestController
public class HelloController {
    @RequestMapping("/hello")
    public String index(@RequestParam String name) {
        try {
            Thread.sleep(10000);
            System.out.println("findished");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "这是服务提供者，参数："+name;
    }
}
