package org.lionsoul.jcseg.elasticsearch;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.lionsoul.jcseg.analyzer.GamaAnalyzer;

/**
 * 并发测试
 */
public class ThreadAnalyzerTest extends Thread{

    private String threadName = "";

    @Override
    public void run(){
        runAnalyzer();
    }

    public ThreadAnalyzerTest(String threadName){
        this.threadName = threadName;
    }

    private void runAnalyzer() {
        try{
            GamaAnalyzer analyzer = new GamaAnalyzer();
            TokenStream ts = analyzer.tokenStream("text", "そのままにしてまともに 一百美元等于多少人民币 " +
                    "뿌리가 깊은 나무 ฉันรักประเทศจีน надежда на отношения и нежность чувств where are you Ce lundi, Angèle a officialisé");
            CharTermAttribute term = ts.addAttribute(CharTermAttribute.class);
            ts.reset();
            while (ts.incrementToken()) {
                System.out.println(threadName+":"+term.toString());
            }
            ts.end();
            ts.close();
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }
}
