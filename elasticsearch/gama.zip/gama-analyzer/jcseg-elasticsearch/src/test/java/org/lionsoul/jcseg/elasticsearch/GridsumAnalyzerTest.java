package org.lionsoul.jcseg.elasticsearch;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.ja.JapaneseAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.lionsoul.jcseg.ISegment;
import org.lionsoul.jcseg.IWord;
import org.lionsoul.jcseg.analyzer.GamaAnalyzer;
import org.lionsoul.jcseg.analyzer.JcsegAnalyzer;
import org.lionsoul.jcseg.dic.ADictionary;
import org.lionsoul.jcseg.dic.DictionaryFactory;
import org.lionsoul.jcseg.segmenter.SegmenterConfig;

import java.io.StringReader;

public class GridsumAnalyzerTest {

    public static void testAnalyzer() throws Exception {
        //日文：中国を愛しています
        //韩文：나 는 중국 을 사랑한다
        //西班牙：Me encanta china
        //法文：Je t 'aime
        //俄文:Я люблю китай
        //泰文:ฉันรักประเทศจีน
        GamaAnalyzer analyzer = new GamaAnalyzer();
        TokenStream ts = analyzer.tokenStream("text", "そのままにしてまともに 一百美元等于多少人民币 " +
                "뿌리가 깊은 나무 ฉันรักประเทศจีน надежда на отношения и нежность чувств where are you Ce lundi, Angèle a officialisé");
        CharTermAttribute term = ts.addAttribute(CharTermAttribute.class);
        ts.reset();
        while (ts.incrementToken()) {
            System.out.println(term.toString());
        }
        ts.end();
        ts.close();

    }

    public static void testJapaneseAnalyzer() throws Exception {
        JapaneseAnalyzer analyzer = new JapaneseAnalyzer();
        TokenStream ts = analyzer.tokenStream("text", "一百美元等于多少人民币そのままにしてまともに");
        CharTermAttribute term = ts.addAttribute(CharTermAttribute.class);
        ts.reset();
        while (ts.incrementToken()) {
            System.out.println(term.toString());
        }
        ts.end();
        ts.close();
    }


    public static void testJcsegAnalyzer() throws Exception {

        //创建SegmenterConfig分词配置实例，自动查找加载jcseg.properties配置项来初始化
        SegmenterConfig config = new SegmenterConfig(true);

        //创建默认单例词库实现，并且按照config配置加载词库
        ADictionary dic = DictionaryFactory.createSingletonDictionary(config);

        //依据给定的ADictionary和SegmenterConfig来创建ISegment
        //为了Api往后兼容，建议使用SegmentFactory来创建ISegment对象
        ISegment seg = ISegment.COMPLEX.factory.create(config, dic);

        //备注：以下代码可以反复调用，seg为非线程安全

        //设置要被分词的文本
        String str = "研究生命起源。";
        seg.reset(new StringReader(str));

        //获取分词结果
        IWord word = null;
        while ( (word = seg.next()) != null ) {
            System.out.println(word.getValue());
        }

        JcsegAnalyzer analyzer = new JcsegAnalyzer(ISegment.COMPLEX,config,dic);
        TokenStream ts = analyzer.tokenStream("text", "一百美元等于多少人民币");
        CharTermAttribute term = ts.addAttribute(CharTermAttribute.class);
        ts.reset();  //设置分词语？
        while (ts.incrementToken()) {
            System.out.println(term.toString());
            org.apache.lucene.analysis.tokenattributes.OffsetAttribute offsetAttribute =
                    ts.getAttribute(org.apache.lucene.analysis.tokenattributes.OffsetAttribute.class);
            System.out.println(offsetAttribute.endOffset());
            System.out.println(offsetAttribute.startOffset());

        }
        ts.end();
        ts.close();
    }

    public static void main(String[] args) throws Exception{
        GridsumAnalyzerTest.testAnalyzer();
//        GridsumAnalyzerTest.testJcsegAnalyzer();
//          GridsumAnalyzerTest.testJapaneseAnalyzer();
//        for(int i = 0 ; i < 10 ; i++){
//            new ThreadAnalyzerTest("线程"+i).start();
//        }

    }
}
