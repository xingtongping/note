package org.lionsoul.jcseg.elasticsearch;

import java.io.UnsupportedEncodingException;

public class TestUnicode {


    /**
     * 判断字符是否为中文
     * @param text
     * @return
     */
    public static boolean isChinese(String text){
       return text.matches("[\u4E00-\u9FA5]+");
    }

    /**
     * 判断字符串是否为日文
     *
     * @param input
     * @return
     */
    public static boolean isJapanese(String input) {
        try {
            return input.getBytes("shift-jis").length >= (2 * input.length());
        } catch (UnsupportedEncodingException e) {
            return false;
        }
    }

    public static void main(String[] args) {
        System.out.println(TestUnicode.isChinese("大|た"));
        System.out.println(TestUnicode.isJapanese("あなたのお父さんとお母さんは大阪に行って、あなたのおじいさんとお婆さんはみんな東京に行って、あなたの弟の妹は北海道に行きました。"));
    }
}
