package org.lionsoul.jcseg.elasticsearch.index.analysis;

import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.env.Environment;
import org.elasticsearch.index.IndexSettings;
import org.elasticsearch.index.analysis.AbstractIndexAnalyzerProvider;
import org.lionsoul.jcseg.analyzer.GamaAnalyzer;

public class GamaAnalyzerProvider extends AbstractIndexAnalyzerProvider<GamaAnalyzer> {

    /**default Jcseg tokenizer instance*/
    private final GamaAnalyzer analyzer;

    public GamaAnalyzerProvider(IndexSettings indexSettings, Environment env, String name, Settings settings) {
        super(indexSettings, name, settings);
        analyzer = new GamaAnalyzer();
    }


    @Override
    public GamaAnalyzer get() {
        return analyzer;
    }
}
