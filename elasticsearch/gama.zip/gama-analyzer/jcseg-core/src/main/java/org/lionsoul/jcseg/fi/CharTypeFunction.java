package org.lionsoul.jcseg.fi;

@FunctionalInterface
public interface CharTypeFunction {
	public boolean is(int c);
}
