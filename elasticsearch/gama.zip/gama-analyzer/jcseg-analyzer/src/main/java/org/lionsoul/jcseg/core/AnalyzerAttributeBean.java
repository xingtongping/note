package org.lionsoul.jcseg.core;

/**
 * 自定义分词元素
 * @author Administrator
 */
public class AnalyzerAttributeBean {

    /**
     * 开始字符位置
     */
    private int startOffset;

    /**
     * 结束字符位置
     */
    private int endOffset;

    /**
     * 占用长度
     */
    private int offsetLength;

    /**
     * 分词结果
     */
    private String token;

    public int getStartOffset() {
        return startOffset;
    }

    public void setStartOffset(int startOffset) {
        this.startOffset = startOffset;
    }

    public int getEndOffset() {
        return endOffset;
    }

    public void setEndOffset(int endOffset) {
        this.endOffset = endOffset;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public int getOffsetLength() {
        return offsetLength;
    }

    public void setOffsetLength(int offsetLength) {
        this.offsetLength = offsetLength;
    }
}
