package org.lionsoul.jcseg.utils;


import org.lionsoul.jcseg.enums.LanguageEnum;

import java.util.regex.Pattern;

/**
 * @author Administrator
 * 识别不同国家的文字
 *         //日文：中国を愛しています
 *         //韩文：나 는 중국 을 사랑한다
 *         //西班牙：Me encanta china
 *         //法文：Je t 'aime
 *         //俄文:Я люблю китай
 *         //泰文:ฉันรักประเทศจีน
 */
public class LanguageRecognizeUtils {

    /**
     * 韩文正则
     */
    private final static Pattern koreanPattern = Pattern.
            compile("^[\\u1100-\\u11ff\\uac00-\\ud7af\\u3130–\\u318F\\u3200–\\u32FF\\uA960–\\uA97F\\uD7B0–\\uD7FF\\uFF00–\\uFFEF]+$");

    /**
     * 判断是否是中文文字
     */
    public static boolean isChinese(String text){
        return text.matches("[\u4E00-\u9FA5]+");
    }

    /**
     * 判断字符串是否为日文
     */
    public static boolean isJapanese(String text) {
        try {
//            return input.getBytes("shift-jis").length >= (2 * input.length());
            return text.matches("[\u3040-\u31FF]+");
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 判断字符串是否为韩文
     */
    public static boolean isKorean(String input) {
        try {
            return koreanPattern.matcher(input).matches();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 判断是否是泰国文字
     * 0E00—0E7F代码点
     */
    public static boolean isThai(String text){
        return text.matches("[\u0E00-\u0E7F]*");
    }

    /**
     * 判断是否是俄文文字
     * x0400-x052f (俄语)([\u0410-\u0451])*
     * \x{0400}-\x{052f}
     */
    public static boolean isRussian(String text){
        return text.matches("[\\x{0400}-\\x{052f}]*");
    }

    /**
     * 判断是否是英文字符
     */
    public static boolean isEnglish(String text){
        return text.matches("[a-zA-Z]");
    }

    /**
     * 识别是哪个国家的文字
     * @param word
     * @return
     */
    public static int getLanguageType(char word){
        if(isChinese(String.valueOf(word))){
            return LanguageEnum.CHINESE.getKey();
        }else if(isJapanese(String.valueOf(word))){
            return LanguageEnum.JAPANESE.getKey();
        }else if(isKorean(String.valueOf(word))){
            return LanguageEnum.KOREAN.getKey();
        }else if(isThai(String.valueOf(word))){
            return LanguageEnum.THAI.getKey();
        }else if(isRussian(String.valueOf(word))){
            return LanguageEnum.RUSSIAN.getKey();
        }else if(isEnglish(String.valueOf(word))){
            return LanguageEnum.RUSSIAN.getKey();
        }
        return LanguageEnum.OTHERS.getKey();
    }

}
