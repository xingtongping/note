package org.lionsoul.jcseg.core;


import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.ja.JapaneseAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.lionsoul.jcseg.analyzer.GamaAnalyzer;
import org.lionsoul.jcseg.analyzer.GamaTokenizer;
import org.lionsoul.jcseg.utils.TokenStreamAnalyzerUtils;



/**
 * 日文分词
 * @author jackson
 */
public class GamaJapaneseAnalyzer {

    private final static JapaneseAnalyzer analyzer = new JapaneseAnalyzer();


    public GamaJapaneseAnalyzer() {

    }

    private static JapaneseAnalyzer getAnalyzer(){
        return analyzer;
    }

    /**
     * 设置分词
     * @param attributeParent
     * @throws Exception
     */
    public static void setAnalyzerAttribute(AnalyzerAttributeParent attributeParent) throws Exception {
        TokenStreamAnalyzerUtils.setAnalyzerAttribute(attributeParent,getAnalyzer());
    }

    public static void testJapaneseAnalyzer() throws Exception {
        /*JapaneseAnalyzer analyzer = new JapaneseAnalyzer();
        TokenStream ts = analyzer.tokenStream("text", "中国を愛しています");*/

        GamaAnalyzer gamaTokenizer = new GamaAnalyzer();
        TokenStream ts = gamaTokenizer.tokenStream("text", "PS4手把造型悠遊卡鑰匙圈");
        GamaTokenizer tokenizer = new GamaTokenizer();
        CharTermAttribute term = ts.addAttribute(CharTermAttribute.class);
        ts.reset();
        while (ts.incrementToken()) {
            System.out.println(term.toString());
        }
        ts.end();
        ts.close();
    }

    public static void main(String[] args) throws Exception{
        GamaJapaneseAnalyzer.testJapaneseAnalyzer();
    }
}
