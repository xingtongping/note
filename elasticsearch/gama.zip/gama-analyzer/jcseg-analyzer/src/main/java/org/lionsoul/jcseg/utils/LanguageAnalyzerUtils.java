package org.lionsoul.jcseg.utils;

import org.lionsoul.jcseg.core.AnalyzerAttributeParent;
import org.lionsoul.jcseg.core.ChineseAnalyzer;
import org.lionsoul.jcseg.core.EnglishAnalyzer;
import org.lionsoul.jcseg.core.GamaJapaneseAnalyzer;
import org.lionsoul.jcseg.core.GamaKoreanAnalyzer;
import org.lionsoul.jcseg.core.GamaRussianAnalyzer;
import org.lionsoul.jcseg.core.GamaThaiAnalyzer;
import org.lionsoul.jcseg.enums.LanguageEnum;

import java.io.Reader;

/**
 * 语言分词Utils
 * @author Jackson
 */
public class LanguageAnalyzerUtils {

    /**
     * 中文分词
     * @param attributeParent
     */
    private static void chooseChineseAnalyze(AnalyzerAttributeParent attributeParent){
        try {
            ChineseAnalyzer.setAnalyzerAttribute(attributeParent);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 日文分词
     * @param attributeParent
     */
    private static void chooseJapaneseAnalyze(AnalyzerAttributeParent attributeParent){
        try {
            GamaJapaneseAnalyzer.setAnalyzerAttribute(attributeParent);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 韩文分词
     */
    private static void chooseKoreanAnalyze(AnalyzerAttributeParent attributeParent){
        try {
            GamaKoreanAnalyzer.setAnalyzerAttribute(attributeParent);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 泰文分词
     */
    private static void chooseThaiAnalyze(AnalyzerAttributeParent attributeParent){
        try {
            GamaThaiAnalyzer.setAnalyzerAttribute(attributeParent);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 俄文分词
     */
    private static void chooseRussianAnalyze(AnalyzerAttributeParent attributeParent){
        try {
            GamaRussianAnalyzer.setAnalyzerAttribute(attributeParent);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 英文分词
     */
    private static void chooseEnglishAnalyze(AnalyzerAttributeParent attributeParent){
        try {
            EnglishAnalyzer.setAnalyzerAttribute(attributeParent);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * 设置具体分词
     */
    public static void setTokenizer(AnalyzerAttributeParent attributeParent){
        if(attributeParent.language == LanguageEnum.CHINESE.getKey()){
            chooseChineseAnalyze(attributeParent);
        }else if(attributeParent.language == LanguageEnum.JAPANESE.getKey()){
            chooseJapaneseAnalyze(attributeParent);
        }else if(attributeParent.language == LanguageEnum.KOREAN.getKey()){
            chooseKoreanAnalyze(attributeParent);
        }else if(attributeParent.language == LanguageEnum.THAI.getKey()){
            chooseThaiAnalyze(attributeParent);
        }else if(attributeParent.language == LanguageEnum.RUSSIAN.getKey()){
            chooseRussianAnalyze(attributeParent);
        }else if(attributeParent.language == LanguageEnum.ENGLISH.getKey()){
            chooseEnglishAnalyze(attributeParent);
        }
    }
}
