package org.lionsoul.jcseg.core;


import org.apache.lucene.analysis.TokenStream;
import org.lionsoul.jcseg.enums.LanguageEnum;
import org.lionsoul.jcseg.util.StringUtil;
import org.lionsoul.jcseg.utils.LanguageAnalyzerUtils;
import org.lionsoul.jcseg.utils.LanguageRecognizeUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * 自定义分词策略
 * 根据不同语言，使用对应的分词器
 */
public class IncrementTokenCustomer {

    /**
     * 所有语种分词结果列表
     */
    private List<AnalyzerAttributeParent> attributeParentList = new ArrayList<>();

    /**
     * 所有语种map
     */
    private LinkedHashMap<Integer,AnalyzerAttributeParent> attributeParentMap = new LinkedHashMap<>();

    /**
     * 记录加载了多少种语言
     */
    private int languageCount = 0;


    /**
     * 初始化attributeParent
     */
    private void initAttributeParent(int type){
        if(this.attributeParentMap.get(type) == null){
            AnalyzerAttributeParent attributeParent = new AnalyzerAttributeParent();
            attributeParent.language = type;
            attributeParentMap.put(type,attributeParent);
            languageCount++;
        }
    }

    public IncrementTokenCustomer(){

    }

    /**
     * 生成不同国家的分词结果
     */
    public List<AttributeDTO> generateAttribute(Reader input){
        //设置输入内容
        setAttributeParentDetail(input);
        StringBuffer inputString = new StringBuffer();
        for(int type : attributeParentMap.keySet()){
            if(!"".equals(attributeParentMap.get(type).textBuilder.toString())){
                AnalyzerAttributeParent attributeParent = attributeParentMap.get(type);
                //设置具体分词内容
                LanguageAnalyzerUtils.setTokenizer(attributeParent);
                attributeParentList.add(attributeParent);
            }
            inputString.append(attributeParentMap.get(type).textBuilder.toString());
        }
        return attributeCorrect(attributeParentList,inputString.toString());
    }


    /**
     * 整合与纠正startOffset、endOffset数值
     */
    public List<AttributeDTO> attributeCorrect(List<AnalyzerAttributeParent> parentList, String input){
        List<AttributeDTO> attributeDTOList = new ArrayList<>();
        //偏移量
        int offset = 0 ;
        for(int index = 0 ; index < parentList.size() ; index++){
            AnalyzerAttributeParent attributeParent = parentList.get(index);
            for(int itemIndex = 0 ; itemIndex < attributeParent.getTokenList().size();itemIndex++){
                AnalyzerAttributeBean bean = attributeParent.getTokenList().get(itemIndex);
                AttributeDTO attributeDTO = new AttributeDTO();
                attributeDTO.setToken(bean.getToken());
                attributeDTO.setStartOffset(bean.getStartOffset() + offset);
                attributeDTO.setEndOffset(bean.getEndOffset() + offset);
                attributeDTOList.add(attributeDTO);
                //每个语言的最后一个元素
                if(itemIndex == (attributeParent.getTokenList().size() - 1)){
                    offset = attributeDTO.getEndOffset();
                }
            }
        }

        if (input.length()>0){
            AttributeDTO attributeDTO = new AttributeDTO();
            attributeDTO.setToken(input);
            attributeDTO.setStartOffset(input.length());
            attributeDTO.setEndOffset(input.length()+input.length()-1);
            attributeDTOList.add(attributeDTO);
        }
        return attributeDTOList;
    }

    /**
     * 获取字符串list
     */
    private void setAttributeParentDetail(Reader input)  {
        try {
            int ci = input.read();
            char ch;
            StringBuilder otherString = new StringBuilder();
            //记录最后一个识别的语种类型
            int lastLanguageType = LanguageEnum.OTHERS.getKey();
            while (true){
                if(ci == -1){
                    break;
                }else {
                    ch = (char) ci;
                    //判断是哪个国家的语言
                    int type = LanguageRecognizeUtils.getLanguageType(ch);
                    if(languageCount < LanguageEnum.getList().size()){
                        initAttributeParent(type);
                    }
                    //如果识别不了是哪个国家的语言，就放下一个能识别的字符前面
                    if(type == LanguageEnum.OTHERS.getKey()){
                        otherString.append(ch);
                    }else {
                        AnalyzerAttributeParent analyzerAttributeParent = attributeParentMap.get(type);
                        analyzerAttributeParent.textBuilder.append(otherString).append(ch);
                        otherString.delete(0,otherString.length());
                        lastLanguageType = type;
                    }
                    ci = input.read();
                }
            }
            //若到最后部分字符存在识别不了情况，应该放到最后一个识别出来的语种中去分词
            if(!"".equals(otherString.toString())){
                this.attributeParentMap.get(lastLanguageType).textBuilder.append(otherString);
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }
}
