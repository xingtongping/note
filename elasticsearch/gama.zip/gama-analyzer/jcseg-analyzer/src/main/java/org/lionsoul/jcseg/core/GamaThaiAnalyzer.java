package org.lionsoul.jcseg.core;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.th.ThaiAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.lionsoul.jcseg.utils.TokenStreamAnalyzerUtils;


/**
 *
 * 泰文分词
 * @author jackson
 */
public class GamaThaiAnalyzer {

    private final static ThaiAnalyzer analyzer = new ThaiAnalyzer();


    public GamaThaiAnalyzer() {

    }

    private static ThaiAnalyzer getAnalyzer(){
        return analyzer;
    }

    /**
     * 设置分词
     * @param attributeParent
     * @throws Exception
     */
    public static void setAnalyzerAttribute(AnalyzerAttributeParent attributeParent) throws Exception {
        TokenStreamAnalyzerUtils.setAnalyzerAttribute(attributeParent,getAnalyzer());
    }

    public static void testAnalyzer() throws Exception {
        ThaiAnalyzer analyzer = new ThaiAnalyzer();
        TokenStream ts = analyzer.tokenStream("text", "ันรักประเทศจีน");
        CharTermAttribute term = ts.addAttribute(CharTermAttribute.class);
        ts.reset();
        while (ts.incrementToken()) {
            System.out.println(term.toString());
        }
        ts.end();
        ts.close();
    }

    public static void main(String[] args) throws Exception{
        GamaThaiAnalyzer.testAnalyzer();
    }
}
