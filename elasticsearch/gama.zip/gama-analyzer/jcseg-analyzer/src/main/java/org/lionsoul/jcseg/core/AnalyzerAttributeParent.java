package org.lionsoul.jcseg.core;

import java.util.ArrayList;

/**
 * @author Administrator
 */
public class AnalyzerAttributeParent {

    public ArrayList<AnalyzerAttributeBean> tokenList;

    /**
     * 整段语言文字
     */
    public StringBuilder textBuilder = new StringBuilder();

    public int language;

    public AnalyzerAttributeParent(){
        tokenList = new ArrayList<>();
    }

    /**
     * 添加元素
     */
    public void add(AnalyzerAttributeBean attributeBean){
        tokenList.add(attributeBean);
    }

    /**
     * 移除某个元素
     */
    public void remove(int index){
        tokenList.remove(index);
    }

    public ArrayList<AnalyzerAttributeBean> getTokenList() {
        return tokenList;
    }

    public void setTokenList(ArrayList<AnalyzerAttributeBean> tokenList) {
        this.tokenList = tokenList;
    }
}
