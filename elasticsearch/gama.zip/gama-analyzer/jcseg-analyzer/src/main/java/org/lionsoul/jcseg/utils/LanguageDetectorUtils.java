package org.lionsoul.jcseg.utils;

import com.google.common.base.Optional;
import com.optimaize.langdetect.LanguageDetector;
import com.optimaize.langdetect.LanguageDetectorBuilder;
import com.optimaize.langdetect.i18n.LdLocale;
import com.optimaize.langdetect.ngram.NgramExtractors;
import com.optimaize.langdetect.profiles.LanguageProfile;
import com.optimaize.langdetect.profiles.LanguageProfileReader;
import com.optimaize.langdetect.text.CommonTextObjectFactories;
import com.optimaize.langdetect.text.TextObject;
import com.optimaize.langdetect.text.TextObjectFactory;

import java.io.IOException;
import java.util.List;

/**
 * 语言检测，单例模式
 */
public class LanguageDetectorUtils {

    private static TextObjectFactory textObjectFactory;
    private static LanguageDetector languageDetector;

    /**
     * 初始化
     */
    private static void singletonInit() throws IOException {
        //load all languages:
        List<LanguageProfile> languageProfiles = new LanguageProfileReader().readAllBuiltIn();
        //build language detector:
        languageDetector = LanguageDetectorBuilder.create(NgramExtractors.standard())
                .withProfiles(languageProfiles)
                .build();
        //create a text object factory
        textObjectFactory = CommonTextObjectFactories.forDetectingOnLargeText();
    }

    private synchronized static TextObjectFactory getTextObjectFactory() throws IOException{
        if(textObjectFactory != null){
            return textObjectFactory;
        }else {
            singletonInit();
            return textObjectFactory;
        }
    }

    public static String detector(CharSequence text) throws Exception{
        TextObject textObject = getTextObjectFactory().forText(text);
        Optional<LdLocale> lang = languageDetector.detect(textObject);
        return lang.toString();
    }


    public static void main(String[] args) throws Exception{
        //中文(简体)，中文(繁体)，英文，日文，韩文，西班牙文，俄文，法文，泰文
        String str = "abcdefghijklmnopqrstuvyzxQWERTYUIOPASDFGHJKLMNBVCXZ";
        System.out.println(LanguageDetectorUtils.detector(str));
        for(char ch : str.toCharArray()){
//            System.out.println(LanguageDetectorUtils.detector(String.valueOf(ch)));
            System.out.println(LanguageRecognizeUtils.isEnglish(String.valueOf(ch)));
        }

    }
}
