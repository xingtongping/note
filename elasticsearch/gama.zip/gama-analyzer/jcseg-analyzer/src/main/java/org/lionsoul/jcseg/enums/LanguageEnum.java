package org.lionsoul.jcseg.enums;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author jackson
 *
 */
public enum LanguageEnum {

    /**
     * 语种与对应的编码
     */

    CHINESE(1, "中文"),
    JAPANESE(2, "日文"),
    KOREAN(3, "韩文"),
    THAI(4, "泰文"),
    RUSSIAN(5, "俄文"),
    ENGLISH(22, "英文"),
    OTHERS(-1,"其他");


    private Integer key;
    private String value;

    public Integer getKey() {
        return key;
    }

    public void setKey(Integer key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    private LanguageEnum(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    // 普通方法
    // 取得 value
    public static String getValue(int index) {
        for (LanguageEnum item : LanguageEnum.values()) {
            if (item.getKey() == index) {
                return item.value;
            }
        }
        return null;
    }

    // 把 enum 转为 list 使用
    public static List<Map> getList() {
        List<Map> list = new ArrayList();
        Map map = null;
        for (LanguageEnum item : LanguageEnum.values()) {
            map = new HashMap();
            map.put("key", item.getKey());
            map.put("value", item.getValue());

            list.add(map);
        }
        return list;
    }

    // 把 enum 转为 list 使用
    public static List<Integer> getKeyList() {
        List<Integer> list = new ArrayList();
        for (LanguageEnum item : LanguageEnum.values()) {
            list.add(item.getKey());
        }
        return list;
    }
}
