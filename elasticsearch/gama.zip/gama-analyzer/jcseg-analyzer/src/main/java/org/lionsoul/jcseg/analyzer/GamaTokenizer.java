package org.lionsoul.jcseg.analyzer;

import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.lionsoul.jcseg.core.AttributeDTO;
import org.lionsoul.jcseg.core.IncrementTokenCustomer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GamaTokenizer extends Tokenizer {

    private final int suffixOffset = 0;
    private int index = 0 ;
    private final CharTermAttribute termAtt = addAttribute(CharTermAttribute.class);
    private final OffsetAttribute offsetAtt = addAttribute(OffsetAttribute.class);
    private List<AttributeDTO> attributeDTOList = new ArrayList<>();


    @Override
    public final boolean incrementToken() throws IOException {
        clearAttributes();
        //自定义方法
        if(attributeDTOList.size() == 0){
            IncrementTokenCustomer customer = new IncrementTokenCustomer();
            attributeDTOList = customer.generateAttribute(input);
        }
        AttributeDTO temAttribute = getAttributeItem(attributeDTOList,index);

        while(true){
            //字符末尾
            if(temAttribute == null){
                return false;
            }else {
                index++;
                termAtt.setEmpty().append(temAttribute.getToken());
                offsetAtt.setOffset(correctOffset(temAttribute.getStartOffset()),
                        correctOffset(temAttribute.getEndOffset()));
                return true;
            }
        }
    }


    @Override
    public final void end() {
        final int finalOffset = correctOffset(suffixOffset);
        this.offsetAtt.setOffset(finalOffset, finalOffset);
    }

    @Override
    public void reset() throws IOException {
        super.reset();
        attributeDTOList.clear();
        index = 0;
    }


    /**
     * 获取attribute子项
     */
    private AttributeDTO getAttributeItem(List<AttributeDTO> list ,int index){
        if(list == null || list.size() == 0 || index >= list.size()){
            return null;
        }
        return list.get(index);
    }
}
