package org.lionsoul.jcseg.core;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.ru.RussianAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.lionsoul.jcseg.utils.TokenStreamAnalyzerUtils;


/**
 *
 * 泰文分词
 * @author jackson
 */
public class GamaRussianAnalyzer {

    private final static RussianAnalyzer analyzer = new RussianAnalyzer();;

    public GamaRussianAnalyzer() {

    }

    private static RussianAnalyzer getAnalyzer(){
        return analyzer;
    }

    /**
     * 设置分词
     * @param attributeParent
     * @throws Exception
     */
    public static void setAnalyzerAttribute(AnalyzerAttributeParent attributeParent) throws Exception {
        TokenStreamAnalyzerUtils.setAnalyzerAttribute(attributeParent,getAnalyzer());
    }

    public static void testAnalyzer() throws Exception {
        RussianAnalyzer analyzer = new RussianAnalyzer();
        TokenStream ts = analyzer.tokenStream("text", "надежда на отношения и нежность чувств");
        CharTermAttribute term = ts.addAttribute(CharTermAttribute.class);
        ts.reset();
        while (ts.incrementToken()) {
            System.out.println(term.toString());
        }
        ts.end();
        ts.close();
    }

    public static void main(String[] args) throws Exception{
        GamaRussianAnalyzer.testAnalyzer();
    }
}
