package org.lionsoul.jcseg.core;

import org.lionsoul.jcseg.ISegment;
import org.lionsoul.jcseg.analyzer.JcsegAnalyzer;
import org.lionsoul.jcseg.dic.ADictionary;
import org.lionsoul.jcseg.dic.DictionaryFactory;
import org.lionsoul.jcseg.segmenter.SegmenterConfig;
import org.lionsoul.jcseg.utils.TokenStreamAnalyzerUtils;

import java.io.Reader;


/**
 *
 * @author Administrator
 */
public class ChineseAnalyzer {

    private static JcsegAnalyzer analyzer;

    static {
        try {
            init();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 初始化
     */
    private static void init() throws Exception{
        //创建SegmenterConfig分词配置实例，自动查找加载jcseg.properties配置项来初始化
        SegmenterConfig config = new SegmenterConfig(true);
        //创建默认单例词库实现，并且按照config配置加载词库
        ADictionary dic = DictionaryFactory.createSingletonDictionary(config);
        analyzer = new JcsegAnalyzer(ISegment.COMPLEX,config,dic);
    }

    private static JcsegAnalyzer getAnalyzer(){
        return analyzer;
    }

    /**
     * 设置分词
     * @param attributeParent
     * @param input
     * @throws Exception
     */
    public static void setAnalyzerAttribute(AnalyzerAttributeParent attributeParent) throws Exception {
        TokenStreamAnalyzerUtils.setAnalyzerAttribute(attributeParent,getAnalyzer());
    }
}
