package org.lionsoul.jcseg.utils;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.lionsoul.jcseg.core.AnalyzerAttributeBean;
import org.lionsoul.jcseg.core.AnalyzerAttributeParent;

import java.util.ArrayList;

/**
 * @author Jackson
 */
public class TokenStreamAnalyzerUtils {

    /**
     * 设置分词
     * @param attributeParent
     * @throws Exception
     */
    public static void setAnalyzerAttribute(AnalyzerAttributeParent attributeParent, Analyzer analyzer) throws Exception {
        ArrayList<AnalyzerAttributeBean> analyzerAttributeBeanList = new ArrayList<>();
        TokenStream ts = analyzer.tokenStream("text", attributeParent.textBuilder.toString());
        CharTermAttribute term = ts.addAttribute(CharTermAttribute.class);
        ts.reset();
        while (ts.incrementToken()) {
            AnalyzerAttributeBean analyzerAttributeBean = new AnalyzerAttributeBean();
            //设置分词内容
            analyzerAttributeBean.setToken(term.toString());
            //设置位置
            org.apache.lucene.analysis.tokenattributes.OffsetAttribute offsetAttribute =
                    ts.getAttribute(org.apache.lucene.analysis.tokenattributes.OffsetAttribute.class);
            analyzerAttributeBean.setStartOffset(offsetAttribute.startOffset());
            analyzerAttributeBean.setEndOffset(offsetAttribute.endOffset());
            analyzerAttributeBean.setOffsetLength(analyzerAttributeBean.getEndOffset()-analyzerAttributeBean.getStartOffset());
            analyzerAttributeBeanList.add(analyzerAttributeBean);
        }
        ts.end();
        ts.close();
        attributeParent.setTokenList(analyzerAttributeBeanList);
    }
}
