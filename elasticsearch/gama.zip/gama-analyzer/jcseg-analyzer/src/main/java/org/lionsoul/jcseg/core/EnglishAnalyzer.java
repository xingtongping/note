package org.lionsoul.jcseg.core;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.core.SimpleAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.lionsoul.jcseg.utils.TokenStreamAnalyzerUtils;


/**
 *
 * @author Administrator
 */
public class EnglishAnalyzer {

    private static StandardAnalyzer analyzer = new StandardAnalyzer();


    private static StandardAnalyzer getAnalyzer(){
        return analyzer;
    }

    /**
     * 设置分词
     * @param attributeParent
     * @throws Exception
     */
    public static void setAnalyzerAttribute(AnalyzerAttributeParent attributeParent) throws Exception {
        TokenStreamAnalyzerUtils.setAnalyzerAttribute(attributeParent,getAnalyzer());
    }


    public static void testEnglishAnalyzer() throws Exception {
        SimpleAnalyzer analyzer = new SimpleAnalyzer();
        TokenStream ts = analyzer.tokenStream("text", "this is a little bird");
        CharTermAttribute term = ts.addAttribute(CharTermAttribute.class);
        ts.reset();
        while (ts.incrementToken()) {
            System.out.println(term.toString());
        }
        ts.end();
        ts.close();
    }

    public static void main(String[] args) throws Exception{
        EnglishAnalyzer.testEnglishAnalyzer();
    }
}
