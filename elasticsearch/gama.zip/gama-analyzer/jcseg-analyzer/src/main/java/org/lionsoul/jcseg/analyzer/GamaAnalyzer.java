package org.lionsoul.jcseg.analyzer;

import org.apache.lucene.analysis.Analyzer;

public class GamaAnalyzer extends Analyzer {

    @Override
    protected TokenStreamComponents createComponents(String fieldName) {
        return new TokenStreamComponents(new GamaTokenizer());
    }
}
