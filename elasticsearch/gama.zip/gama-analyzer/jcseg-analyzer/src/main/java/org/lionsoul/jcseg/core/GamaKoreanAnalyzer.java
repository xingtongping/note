package org.lionsoul.jcseg.core;


import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.ko.KoreanAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.lionsoul.jcseg.utils.TokenStreamAnalyzerUtils;



/**
 * 日文分词
 * @author jackson
 */
public class GamaKoreanAnalyzer {

    private final static KoreanAnalyzer analyzer = new KoreanAnalyzer();


    public GamaKoreanAnalyzer() {

    }

    private static KoreanAnalyzer getAnalyzer(){
        return analyzer;
    }

    /**
     * 设置分词
     * @param attributeParent
     * @throws Exception
     */
    public static void setAnalyzerAttribute(AnalyzerAttributeParent attributeParent) throws Exception {
        TokenStreamAnalyzerUtils.setAnalyzerAttribute(attributeParent,getAnalyzer());
    }

    public static void testAnalyzer() throws Exception {
        KoreanAnalyzer analyzer = new KoreanAnalyzer();
        TokenStream ts = analyzer.tokenStream("text", "뿌리가 깊은 나무");
        CharTermAttribute term = ts.addAttribute(CharTermAttribute.class);
        ts.reset();
        while (ts.incrementToken()) {
            System.out.println(term.toString());
        }
        ts.end();
        ts.close();
    }

    public static void main(String[] args) throws Exception{
        GamaKoreanAnalyzer.testAnalyzer();
    }
}
